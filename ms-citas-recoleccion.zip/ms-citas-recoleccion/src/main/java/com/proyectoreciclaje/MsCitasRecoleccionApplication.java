package com.proyectoreciclaje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsCitasRecoleccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsCitasRecoleccionApplication.class, args);
	}

}
